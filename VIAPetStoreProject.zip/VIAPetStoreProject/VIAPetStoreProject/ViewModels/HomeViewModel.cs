﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIAPetStoreProject.Data.Models;

namespace VIAPetStoreProject.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Pet> Pets { get; set; }
    }
}
