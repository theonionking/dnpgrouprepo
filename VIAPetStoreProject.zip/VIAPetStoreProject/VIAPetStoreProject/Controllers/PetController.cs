﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using VIAPetStoreProject.Data.Interfaces;
using VIAPetStoreProject.Data.Models;
using VIAPetStoreProject.ViewModels;

namespace VIAPetStoreProject.Controllers
{
    public class PetController : Controller
    {
        private readonly IPetRepository _petRepository;
        public PetController(IPetRepository petRepository)
        {
            _petRepository = petRepository;
        }

        public ViewResult List(bool type)
        {
            bool _isTaken = type;
            IEnumerable<Pet> pets;

            if(_isTaken)
            {
                pets = _petRepository.Pets.Where(p => p.IsTaken == true);
            }
            else
            {
                pets = _petRepository.Pets.Where(p => p.IsTaken == false);
            }

            var petListViewModel = new PetListViewModel
            {
                Pets = pets,
            };

            return View(petListViewModel);
        }

        
    }
}
