﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using VIAPetStoreProject.Data.Interfaces;
using VIAPetStoreProject.Data.Models;
using VIAPetStoreProject.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VIAPetStoreProject.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly IPetRepository _petRepository;
        private readonly ShoppingCart _shoppingCart;
        public ShoppingCartController(IPetRepository petRepository, ShoppingCart shoppingCart)
        {
            _petRepository = petRepository;
            _shoppingCart = shoppingCart;
        }
        
        public ViewResult Index()
        {
            var items = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = items;

            var sCVM = new ShoppingCartViewModel
            {
                ShoppingCart = _shoppingCart,
                ShoppingCartTotal = _shoppingCart.GetShoppingCartTotal()
            };

            return View(sCVM);
        }

        public RedirectToActionResult AddToShoppingCart(int petID)
        {
            var selectedPet = _petRepository.Pets.FirstOrDefault(p => p.PetID == petID) ;

            if(selectedPet != null)
            {
                _shoppingCart.AddToCart(selectedPet);
            }
            return RedirectToAction("Index");
        }

        public RedirectToActionResult RemoveFromShoppingCart(int petID)
        {
            var selectedPet = _petRepository.Pets.FirstOrDefault(p => p.PetID == petID);

            if (selectedPet != null)
            {
                _shoppingCart.RemoveFromCart(selectedPet);
            }
            return RedirectToAction("Index");
        }
    }
}
