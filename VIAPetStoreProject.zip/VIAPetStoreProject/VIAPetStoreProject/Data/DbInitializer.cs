﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using VIAPetStoreProject.Data.Models;

namespace VIAPetStoreProject.Data
{
    public class DbInitializer
    {
        public static void Seed(AppDbContext context)
        {
            context.Database.EnsureCreated();

            // Look for any pets.
            if (context.Pets.Any())
            {
                return;   // DB has been seeded/seeded before
            }

            var pets = new Pet[]
            {
                    new Pet
                    {
                        ImageURL = "https://goo.gl/UfjTE3",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 100.00M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/Vz3bVA",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 82.50M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/yFqP7r",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 55.25M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/d62Pv8",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 300.00M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/FzHecc",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 182.30M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/CbYLzx",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 62.11M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/RrhKPT",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 111.11M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/Y3nqMt",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 222.10M,
                        IsTaken = false
                    },
                    new Pet
                    {
                        ImageURL = "https://goo.gl/FWBVM6",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 95.99M,
                        IsTaken = false
                    }

            };

            foreach (Pet p in pets)
            {
                context.Pets.Add(p);
            }
            context.SaveChanges();
        }
    }
}
