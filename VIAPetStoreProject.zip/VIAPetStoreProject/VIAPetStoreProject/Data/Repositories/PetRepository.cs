﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIAPetStoreProject.Data.Interfaces;
using VIAPetStoreProject.Data.Models;

namespace VIAPetStoreProject.Data.Repositories
{
    public class PetRepository : IPetRepository
    {
        private readonly AppDbContext _appDbContext;

        public PetRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public IEnumerable<Pet> Pets => _appDbContext.Pets;

        public Pet GetPetByID(int petID) => _appDbContext.Pets.FirstOrDefault(p => p.PetID == petID);
    }
}
