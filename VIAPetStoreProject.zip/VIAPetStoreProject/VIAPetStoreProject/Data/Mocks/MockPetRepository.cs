﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIAPetStoreProject.Data.Interfaces;
using VIAPetStoreProject.Data.Models;

namespace VIAPetStoreProject.Data.Mocks
{
    public class MockPetRepository : IPetRepository
    {
        public IEnumerable<Pet> Pets
        {
            get
            {
                return new List<Pet>
                {
                    new Pet {
                        ImageURL = "https://www.cathealth.com/images/cozy_cat_home.jpg",     
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 100.00M,
                        IsTaken = false
                    },
                    new Pet {
                        ImageURL = "http://catguide.com/wp-content/uploads/2016/07/Cat-Spraying-Causes-and-Cures-2-200x200.jpg",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 82.50M,
                        IsTaken = false
                    },
                    new Pet {
                        ImageURL = "https://goo.gl/yFqP7r",
                        Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam non felis viverra, ullamcorper massa quis, tincidunt ex. Vestibulum lobortis, dui quis condimentum elementum, turpis lacus varius dolor, id porta orci magna eu nibh. Nam sit amet dui sagittis, varius urna pulvinar, vulputate tortor.",
                        Price = 55.25M,
                        IsTaken = false
                    }
                };
            }
        }

        public Pet GetPetByID(int petID)
        {
            throw new NotImplementedException();
        }
    }
}
