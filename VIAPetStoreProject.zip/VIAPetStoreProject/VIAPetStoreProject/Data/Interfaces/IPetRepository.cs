﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIAPetStoreProject.Data.Models;

namespace VIAPetStoreProject.Data.Interfaces
{
    public interface IPetRepository
    {
        IEnumerable<Pet> Pets { get; }
        Pet GetPetByID(int petID);
    }
}
