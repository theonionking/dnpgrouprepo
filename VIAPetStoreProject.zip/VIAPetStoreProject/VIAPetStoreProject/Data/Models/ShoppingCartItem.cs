﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VIAPetStoreProject.Data.Models
{
    public class ShoppingCartItem
    {
        public int ShoppingCartItemID { get; set; }
        public Pet Pet { get; set; }
        public string ShoppingCartID { get; set; }
    }
}
